import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

def task_func(x, y, labels):
    data = np.column_stack((np.asarray(x), np.asarray(y)))
    pca = PCA(n_components=2)
    pca_results = pca.fit_transform(data)
    fig, ax = plt.subplots()
    labels_arr = np.asarray(labels)
    unique_labels = np.unique(labels_arr)
    for lab in unique_labels:
        mask = labels_arr == lab
        ax.scatter(pca_results[mask, 0], pca_results[mask, 1], label=str(lab))
    ax.set_xlabel('Principal Component 1')
    ax.set_ylabel('Principal Component 2')
    ax.set_title('PCA Results')
    ax.legend()
    return pca_results, fig
