import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
from scipy.stats import chi2_contingency

def task_func(df1, df2, column1="feature1", column2="feature2"):
    merged = pd.merge(df1, df2, on="id")
    contingency = pd.crosstab(merged[column1], merged[column2])
    chi2, p, dof, expected = chi2_contingency(contingency)
    ax = sns.heatmap(contingency, annot=True, fmt="d")
    return p, ax
