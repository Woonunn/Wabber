import binascii
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def task_func(hex_str):
    if hex_str is None:
        raise ValueError("Invalid hex string")
    s = hex_str
    # Strip escaped '\\x' prefixes (literal backslash + x)
    s = s.replace('\\x', '')
    # Also handle a leading '0x' or '0X'
    if s.startswith('0x') or s.startswith('0X'):
        s = s[2:]
    # Remove whitespace
    s = ''.join(s.split())
    if len(s) % 2 != 0:
        raise ValueError("Invalid hex string")
    try:
        data = binascii.unhexlify(s)
    except (binascii.Error, ValueError):
        raise ValueError("Invalid hex string")
    if len(data) == 0:
        byte_freq_df = pd.DataFrame(columns=['Byte Value', 'Frequency'])
        byte_freq_df['Byte Value'] = byte_freq_df['Byte Value'].astype(int)
        byte_freq_df['Frequency'] = byte_freq_df['Frequency'].astype(int)
    else:
        arr = np.frombuffer(data, dtype=np.uint8)
        values, counts = np.unique(arr, return_counts=True)
        byte_freq_df = pd.DataFrame({'Byte Value': values.astype(int), 'Frequency': counts.astype(int)})
    fig, ax = plt.subplots()
    ax.bar(byte_freq_df['Byte Value'], byte_freq_df['Frequency'])
    ax.set_xlabel('Byte Value')
    ax.set_ylabel('Frequency')
    return byte_freq_df, ax
