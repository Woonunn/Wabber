from scipy import stats
import matplotlib.pyplot as plt

def task_func(data_dict, data_keys):
    x = data_dict[data_keys[0]]
    y = data_dict[data_keys[1]]
    corr, _ = stats.pearsonr(x, y)
    fig, ax = plt.subplots()
    ax.scatter(x, y)
    ax.set_xlabel(data_keys[0])
    ax.set_ylabel(data_keys[1])
    return corr, ax
