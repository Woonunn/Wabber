import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import numpy as np

def task_func(myList, n_clusters):
    if myList is None or n_clusters is None:
        raise ValueError("Invalid inputs")
    try:
        points = np.array(myList, dtype=float)
    except (TypeError, ValueError):
        raise ValueError("Invalid inputs")
    if points.ndim != 2 or points.shape[1] != 2 or points.shape[0] == 0:
        raise ValueError("Invalid inputs")
    if not isinstance(n_clusters, (int, np.integer)) or n_clusters <= 0:
        raise ValueError("Invalid inputs")
    if n_clusters > points.shape[0]:
        raise ValueError("Invalid inputs")
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = kmeans.fit_predict(points)
    centroids = kmeans.cluster_centers_
    fig, ax = plt.subplots()
    ax.scatter(points[:, 0], points[:, 1], c=labels, cmap='viridis')
    ax.scatter(centroids[:, 0], centroids[:, 1], marker='x', color='red', s=100)
    return ax, centroids
