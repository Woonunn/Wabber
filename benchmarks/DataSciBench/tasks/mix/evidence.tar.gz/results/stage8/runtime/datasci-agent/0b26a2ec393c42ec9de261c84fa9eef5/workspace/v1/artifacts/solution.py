import numpy as np
import bisect
import statistics
import matplotlib.pyplot as plt

def task_func(data, value):
    if len(data) == 0:
        return np.array([]), 0
    arr = np.array(data)
    avg = np.mean(arr)
    greater_than_avg = arr[arr > avg]
    count_greater_than_value = int(np.sum(arr > value))
    sorted_data = np.sort(arr)
    plt.hist(sorted_data)
    plt.show()
    return greater_than_avg, count_greater_than_value
