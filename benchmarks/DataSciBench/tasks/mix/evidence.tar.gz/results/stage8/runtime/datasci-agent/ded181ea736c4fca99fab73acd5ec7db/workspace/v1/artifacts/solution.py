import pandas as pd
from matplotlib import pyplot as plt

def task_func(arr):
    if arr.size == 0:
        fig, ax = plt.subplots()
        ax.set_title('Time Series of Row Sums')
        row_sums_df = pd.DataFrame()
        return row_sums_df, ax
    row_sums = arr.sum(axis=1)
    dates = pd.date_range(start='2020-01-01', periods=len(row_sums))
    row_sums_df = pd.DataFrame({'Row Sums': row_sums}, index=dates)
    fig, ax = plt.subplots()
    ax.plot(row_sums_df.index, row_sums_df['Row Sums'])
    ax.set_title('Time Series of Row Sums')
    return row_sums_df, ax
