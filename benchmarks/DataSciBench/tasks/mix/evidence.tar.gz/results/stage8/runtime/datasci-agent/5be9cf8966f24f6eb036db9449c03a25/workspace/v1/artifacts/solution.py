import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

def task_func(dataframe, target_value='332'):
    bool_df = dataframe.applymap(lambda x: x == target_value)
    fig, ax = plt.subplots()
    sns.heatmap(bool_df.astype(int), ax=ax)
    return bool_df, ax
