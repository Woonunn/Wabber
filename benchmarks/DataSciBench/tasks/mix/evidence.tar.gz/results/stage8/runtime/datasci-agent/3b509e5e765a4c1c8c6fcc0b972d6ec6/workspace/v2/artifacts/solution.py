import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def task_func(arr):
    arr = np.asarray(arr)
    row_sums = np.sum(arr, axis=1)
    print(row_sums)
    vmin = np.min(arr)
    vmax = np.max(arr)
    fig, ax = plt.subplots()
    sns.heatmap(arr, ax=ax, vmin=vmin, vmax=vmax)
    ax.set_title('Heatmap of the 2D Array')
    return row_sums, ax
