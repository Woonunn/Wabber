import numpy as np
from scipy.stats import norm

def task_func(data: np.ndarray, threshold: float = 2.0) -> list:
    mean, std = norm.fit(data)
    var = std ** 2
    if std == 0:
        return [], mean, var
    z_scores = (data - mean) / std
    outliers = [int(i) for i in np.where(np.abs(z_scores) > threshold)[0]]
    return outliers, mean, var
