import matplotlib
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

def task_func(df):
    df = df.copy()
    scaler = StandardScaler()
    df[['Age', 'Score']] = scaler.fit_transform(df[['Age', 'Score']])
    df = df.drop_duplicates(subset='Name')
    fig, ax = plt.subplots()
    ax.scatter(df['Age'], df['Score'])
    ax.set_title('Scatter Plot of Standardized Age and Score')
    ax.set_xlabel('Age (standardized)')
    ax.set_ylabel('Score (standardized)')
    return df, ax
