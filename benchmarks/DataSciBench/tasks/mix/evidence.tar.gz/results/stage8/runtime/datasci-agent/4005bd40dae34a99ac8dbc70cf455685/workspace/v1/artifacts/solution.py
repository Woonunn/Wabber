import numpy as np
from operator import itemgetter
import matplotlib.pyplot as plt

def task_func(data):
    xs = [t[0] for t in data]
    ys = [t[1] for t in data]
    max_tuple = max(data, key=itemgetter(1))
    fig, ax = plt.subplots()
    ax.scatter(xs, ys, label='data')
    ax.scatter([max_tuple[0]], [max_tuple[1]], color='red', label='max tuple')
    ax.set_title('Max Tuple Highlighted')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.legend()
    return ax, max_tuple
