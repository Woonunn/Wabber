import pandas as pd
import seaborn as sns

def task_func(array):
    if not array or len(array) == 0:
        raise ValueError("Input array is empty")
    lengths = set(len(row) for row in array)
    if len(lengths) > 1:
        raise ValueError("Sublists have varying lengths")
    df = pd.DataFrame(array, columns=['A', 'B', 'C', 'D', 'E'])
    corr = df.corr()
    heatmap = sns.heatmap(corr)
    return df, heatmap
