import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt

def task_func(data):
    required_keys = ['Salary_String', 'Experience']
    if not all(key in data for key in required_keys):
        raise ValueError("Input data must contain 'Salary_String' and 'Experience' keys.")

    df = pd.DataFrame(data)

    if df.empty:
        fig, ax = plt.subplots()
        ax.set_xlabel('Experience')
        ax.set_ylabel('Normalized Salary')
        return ax, df

    try:
        df['Salary'] = df['Salary_String'].apply(lambda x: float(str(x).replace(',', '')))
    except ValueError as e:
        raise ValueError("Error converting Salary_String to float: {}".format(e))

    scaler = MinMaxScaler()
    df['Normalized_Salary'] = scaler.fit_transform(df[['Salary']])

    fig, ax = plt.subplots()
    ax.scatter(df['Experience'], df['Normalized_Salary'])
    ax.set_xlabel('Experience')
    ax.set_ylabel('Normalized Salary')

    return ax, df
