import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
import seaborn as sns
import matplotlib.pyplot as plt

def task_func(df: pd.DataFrame):
    numeric_df = df.select_dtypes(include=[np.number])
    numeric_df = numeric_df.fillna(numeric_df.mean())
    pca = PCA(n_components=2)
    components = pca.fit_transform(numeric_df)
    pca_df = pd.DataFrame(components, columns=['Component 1', 'Component 2'])
    fig, ax = plt.subplots()
    sns.scatterplot(x='Component 1', y='Component 2', data=pca_df, ax=ax)
    ax.set_xlabel('Component 1')
    ax.set_ylabel('Component 2')
    return pca_df, ax
