import pandas as pd
import numpy as np

def task_func(data, cols):
    df = pd.DataFrame(data, columns=cols)
    numeric_df = df.select_dtypes(include=[np.number])
    correlation_matrix = numeric_df.corr()
    return (correlation_matrix,)