import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

def task_func(df, column, bins=30, density=True, alpha=0.6, color="g", seed=None):
    if seed is not None:
        np.random.seed(seed)
    data = df[column].dropna()
    fig, ax = plt.subplots()
    ax.hist(data, bins=bins, density=density, alpha=alpha, color=color)
    mu, std = norm.fit(data)
    xmin, xmax = ax.get_xlim()
    x = np.linspace(xmin, xmax, 100)
    p = norm.pdf(x, mu, std)
    ax.plot(x, p, 'k', linewidth=2)
    return ax, mu, std
