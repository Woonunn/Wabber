import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from matplotlib.collections import PathCollection

def task_func(data, n_clusters=3):
    if not isinstance(data, pd.DataFrame):
        raise ValueError("'data' must be a pd.DataFrame.")
    if not isinstance(n_clusters, int) or isinstance(n_clusters, bool) or n_clusters <= 1:
        raise ValueError("'n_clusters' must be an integer greater than 1.")

    numeric_data = data.select_dtypes(include=[np.number])
    if numeric_data.shape[1] < 2:
        numeric_data = data.apply(pd.to_numeric, errors='coerce').fillna(0)

    X = numeric_data.values

    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    cluster_labels = kmeans.fit_predict(X)
    centroids = kmeans.cluster_centers_

    fig, ax = plt.subplots()
    scatter = ax.scatter(X[:, 0], X[:, 1], c=cluster_labels, cmap='viridis', alpha=0.6)
    ax.scatter(centroids[:, 0], centroids[:, 1], c='red', marker='X', s=200, edgecolors='black', label='Centroids')
    ax.set_title('K-means Clustering')
    ax.set_xlabel(numeric_data.columns[0])
    ax.set_ylabel(numeric_data.columns[1])
    ax.legend()

    return cluster_labels, ax
