import pandas as pd
import matplotlib.pyplot as plt

def task_func(matrix):
    fig, ax = plt.subplots()
    heatmap = ax.imshow(matrix, cmap='hot', interpolation='nearest')
    return ax, heatmap
