import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from sklearn.datasets import load_diabetes

def task_func():
    plt.rcParams['font.family'] = 'Arial'
    diabetes = load_diabetes()
    diabetes_df = pd.DataFrame(diabetes.data, columns=diabetes.feature_names)
    pairplot_fig = sns.pairplot(diabetes_df)
    return pairplot_fig.fig, diabetes_df
