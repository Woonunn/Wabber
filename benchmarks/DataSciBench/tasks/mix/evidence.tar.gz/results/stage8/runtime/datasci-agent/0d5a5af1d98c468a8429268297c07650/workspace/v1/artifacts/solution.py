import pandas as pd
import matplotlib.pyplot as plt

COLORS = ['r', 'g', 'b', 'y', 'm']

def task_func(df, col, title=None):
    if not isinstance(df, pd.DataFrame) or df.empty or col not in df.columns:
        raise ValueError("Invalid input")
    unique_counts = df[col].value_counts().to_dict()
    labels = list(unique_counts.keys())
    sizes = list(unique_counts.values())
    colors = [COLORS[i % len(COLORS)] for i in range(len(sizes))]
    fig, ax = plt.subplots()
    ax.pie(sizes, labels=labels, colors=colors)
    if title is not None:
        ax.set_title(title)
    return ax, unique_counts
