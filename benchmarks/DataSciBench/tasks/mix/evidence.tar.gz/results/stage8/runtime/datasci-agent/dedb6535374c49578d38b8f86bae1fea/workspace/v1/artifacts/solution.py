from itertools import chain
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

def task_func(L):
    data = list(chain.from_iterable(L))
    X = np.array(data).reshape(-1, 1)
    kmeans = KMeans(n_clusters=2, random_state=0, n_init=10)
    labels = kmeans.fit_predict(X)
    fig, ax = plt.subplots()
    ax.scatter(X[:, 0], np.zeros(len(X)), c=labels, cmap='viridis')
    return ax, labels
