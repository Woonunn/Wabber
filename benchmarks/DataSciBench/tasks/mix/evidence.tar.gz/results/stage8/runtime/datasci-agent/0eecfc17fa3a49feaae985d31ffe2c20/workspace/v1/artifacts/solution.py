from itertools import chain
import numpy as np
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

def task_func(L):
    flat = list(chain.from_iterable(L))
    arr = np.array(flat).reshape(-1, 1)
    scaler = StandardScaler()
    standardized = scaler.fit_transform(arr).flatten().tolist()
    fig, ax = plt.subplots()
    ax.plot(standardized)
    return standardized, ax
