import numpy as np
import itertools

def task_func(data_list, file_name):
    if not data_list:
        with open(file_name, 'w') as f:
            pass
        return ([], True)

    max_len = max(len(t) for t in data_list)
    num_positions = max_len - 1

    columns = [[] for _ in range(num_positions)]
    for t in data_list:
        for i in range(num_positions):
            idx = i + 1
            if idx < len(t):
                val = t[idx]
                if isinstance(val, (int, float, np.integer, np.floating)) and not isinstance(val, bool):
                    columns[i].append(float(val))
                else:
                    columns[i].append(np.nan)
            else:
                columns[i].append(np.nan)

    mean_values = []
    for col in columns:
        arr = np.array(col, dtype=float)
        if arr.size == 0 or np.all(np.isnan(arr)):
            mean_values.append(np.nan)
        else:
            mean_values.append(float(np.nanmean(arr)))

    with open(file_name, 'w') as f:
        for i, m in enumerate(mean_values):
            f.write(f"Position {i + 1}: {m}\n")

    return (mean_values, True)
