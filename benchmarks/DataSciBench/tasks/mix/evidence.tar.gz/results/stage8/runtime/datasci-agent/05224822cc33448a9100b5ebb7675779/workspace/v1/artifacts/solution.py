import itertools
import numpy as np
import matplotlib.pyplot as plt

def task_func(elements, subset_size):
    subsets = list(itertools.combinations(elements, subset_size))
    sums = [sum(subset) for subset in subsets]
    fig, ax = plt.subplots()
    ax.hist(sums)
    return ax, subsets, sums
