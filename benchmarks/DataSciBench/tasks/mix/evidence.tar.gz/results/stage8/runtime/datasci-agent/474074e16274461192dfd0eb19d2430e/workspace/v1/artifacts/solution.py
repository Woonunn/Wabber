import pandas as pd
from sklearn.decomposition import PCA

def task_func(df):
    pca = PCA(n_components=2)
    components = pca.fit_transform(df)
    df_pca = pd.DataFrame(components, columns=['PC1', 'PC2'])
    explained_var = list(pca.explained_variance_ratio_)
    return df_pca, explained_var
