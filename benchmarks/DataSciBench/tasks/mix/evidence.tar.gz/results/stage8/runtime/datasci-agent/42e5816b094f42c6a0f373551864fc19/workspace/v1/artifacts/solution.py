import pandas as pd
import regex as re
import seaborn as sns
import matplotlib.pyplot as plt
COLUMN_NAMES = ["Name", "Email", "Age", "Country"]

def task_func(text):
    pattern = r"Name: (.*?), Email: (.*?), Age: (.*?), Country: (.*?)($|\n)"
    matches = re.findall(pattern, text)
    data = [list(m[:4]) for m in matches]
    df = pd.DataFrame(data, columns=COLUMN_NAMES)
    df['Age'] = pd.to_numeric(df['Age'], errors='coerce')
    fig, ax = plt.subplots()
    sns.histplot(df['Age'].dropna(), ax=ax)
    ax.set_title('Age Distribution')
    ax.set_xlabel('Age')
    ax.set_ylabel('Count')
    return df, fig
