import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def task_func(df):
    if not isinstance(df, pd.DataFrame) or df.empty:
        raise ValueError("Input must be a non-empty DataFrame.")
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) == 0:
        raise ValueError("DataFrame must contain at least one numeric column.")
    hist_axes = []
    for col in numeric_cols:
        fig, ax = plt.subplots()
        ax.hist(df[col].dropna(), bins=10)
        ax.set_title(str(col))
        ax.set_xlabel('Value')
        ax.set_ylabel('Frequency')
        hist_axes.append(ax)
    return hist_axes, len(hist_axes)
