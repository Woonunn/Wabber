from sklearn.preprocessing import StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

def task_func(df):
    df_filled = df.copy()
    numeric_cols = df_filled.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        df_filled[col] = df_filled[col].fillna(df_filled[col].mean())
    scaler = StandardScaler()
    standardized = df_filled.copy()
    if len(numeric_cols) > 0:
        standardized[numeric_cols] = scaler.fit_transform(df_filled[numeric_cols])
    corr = standardized[numeric_cols].corr() if len(numeric_cols) > 0 else standardized.corr()
    fig, ax = plt.subplots()
    sns.heatmap(corr, ax=ax)
    return standardized, ax
