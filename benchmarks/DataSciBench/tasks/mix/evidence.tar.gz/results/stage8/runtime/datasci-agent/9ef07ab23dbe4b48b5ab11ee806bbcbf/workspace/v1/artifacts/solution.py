import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

PLOT_TITLE = "Value Distribution"

def task_func(data_dict):
    df = pd.DataFrame(data_dict)
    df = df.dropna()
    if df.empty:
        return df, None
    values = df.values.flatten()
    if len(values) == 0 or np.all(values == values[0]):
        return df, None
    min_val = df.min().min()
    max_val = df.max().max()
    n = len(values)
    bins = max(2, min(11, n // 2))
    bin_edges = np.linspace(min_val, max_val, bins + 1)
    fig, ax = plt.subplots()
    sns.histplot(values, bins=bin_edges, kde=False, ax=ax)
    ax.set_title(PLOT_TITLE)
    return df, ax
