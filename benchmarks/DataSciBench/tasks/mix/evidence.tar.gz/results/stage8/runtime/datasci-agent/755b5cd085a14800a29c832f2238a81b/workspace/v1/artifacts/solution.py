import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

def task_func(data):
    df = pd.DataFrame(data)
    if df.empty:
        raise ValueError("The DataFrame is empty.")
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.empty or numeric_df.shape[1] == 0:
        raise ValueError("No numeric columns are present.")
    cumulative_sum_df = numeric_df.cumsum()
    ax = sns.heatmap(cumulative_sum_df)
    return ax, cumulative_sum_df
