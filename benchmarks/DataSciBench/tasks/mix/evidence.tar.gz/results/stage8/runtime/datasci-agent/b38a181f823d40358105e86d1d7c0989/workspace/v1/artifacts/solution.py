import pandas as pd
from scipy.spatial import distance
import matplotlib.pyplot as plt

def task_func(a, b):
    euclidean_dist = distance.euclidean(a, b)
    df = pd.DataFrame({'A': a, 'B': b})
    fig, ax = plt.subplots()
    df.plot(ax=ax)
    ax.set_title(f'Euclidean Distance: {euclidean_dist:.2f}')
    return euclidean_dist, df, ax
