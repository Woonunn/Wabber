import pandas as pd
import matplotlib.pyplot as plt

def task_func(df, letters=list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')):
    if not isinstance(df, pd.DataFrame) or 'Letters' not in df.columns:
        raise ValueError("Input must be a DataFrame with a 'Letters' column")
    letter_counts = df['Letters'].value_counts().reindex(letters, fill_value=0)
    fig, ax = plt.subplots()
    ax.bar(letter_counts.index, letter_counts.values)
    ax.set_xlabel('Letters')
    ax.set_ylabel('Frequency')
    ax.set_title('Letter Frequency')
    return ax, letter_counts
