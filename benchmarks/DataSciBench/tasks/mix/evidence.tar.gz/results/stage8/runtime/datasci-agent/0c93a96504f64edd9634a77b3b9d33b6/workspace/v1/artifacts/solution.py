import heapq
import math
import matplotlib.pyplot as plt

def task_func(l1, l2, N=10):
    diffs = [math.sqrt((a - b) ** 2) for a, b in zip(l1, l2)]
    biggest = heapq.nlargest(N, diffs)
    fig, ax = plt.subplots()
    ax.plot(biggest)
    return ax, biggest
