import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
import re

def task_func(example_str):
    # Extract all texts not enclosed in square brackets
    extracted_text = re.sub(r'\[[^\]]*\]', '', example_str)
    # Tokenize into words
    words = re.findall(r'\b\w+\b', extracted_text)
    if not words:
        return extracted_text, {}
    # Compute TF-IDF on the extracted text as a single document
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([extracted_text])
    feature_names = vectorizer.get_feature_names_out()
    scores = tfidf_matrix.toarray()[0]
    tfidf_dict = {word: float(score) for word, score in zip(feature_names, scores)}
    return extracted_text, tfidf_dict
