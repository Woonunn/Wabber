import pandas as pd
from sklearn.cluster import KMeans

def task_func(data, n_clusters=3, seed=None):
    if not all(pd.api.types.is_numeric_dtype(data[col]) for col in data.columns):
        raise ValueError("DataFrame contains non-numeric entries")
    model = KMeans(n_clusters=n_clusters, n_init=10, random_state=seed)
    labels = model.fit_predict(data)
    return labels, model
