import re
from string import punctuation
import seaborn as sns
import matplotlib.pyplot as plt

PUNCTUATION = set(punctuation)

def task_func(text):
    tokens = re.findall(r'\S+', text)
    words = []
    for tok in tokens:
        if tok.startswith('$'):
            rest = tok[1:]
            if rest and any(ch not in PUNCTUATION for ch in rest):
                words.append(tok)
    if not words:
        return None, False
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    keys = list(freq.keys())
    values = [freq[k] for k in keys]
    fig, ax = plt.subplots()
    sns.barplot(x=keys, y=values, ax=ax)
    ax.set_xlabel('Words')
    ax.set_ylabel('Frequency')
    return ax, True
