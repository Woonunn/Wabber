import heapq
from sklearn.linear_model import LinearRegression

def task_func(df, feature, target, n=10):
    if feature not in df.columns or target not in df.columns:
        raise ValueError("Specified columns are not in the provided DataFrame.")
    X = df[[feature]].values
    y = df[target].values
    model = LinearRegression()
    model.fit(X, y)
    residuals = y - model.predict(X)
    abs_residuals = [abs(r) for r in residuals]
    n = min(n, len(abs_residuals))
    indices = heapq.nlargest(n, range(len(abs_residuals)), key=lambda i: abs_residuals[i])
    return indices, model
