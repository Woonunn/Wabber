import numpy as np
import pandas as pd

def task_func(df, letter):
    data = pd.DataFrame(df)
    filtered = data[data['Word'].astype(str).str.startswith(letter)]
    word_lengths = filtered['Word'].astype(str).str.len()
    stats_dict = {
        'mean': word_lengths.mean(),
        'median': word_lengths.median(),
        'mode': word_lengths.mode().iloc[0] if not word_lengths.mode().empty else np.nan
    }
    return stats_dict, word_lengths
