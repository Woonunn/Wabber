import warnings
import sklearn.model_selection as model_selection
import sklearn.svm as svm
import sklearn.datasets as datasets
import sklearn.metrics as metrics

def task_func():
    iris = datasets.load_iris()
    X_train, X_test, y_train, y_test = model_selection.train_test_split(
        iris.data, iris.target, test_size=0.33
    )
    clf = svm.SVC()
    clf.fit(X_train, y_train)
    predictions = clf.predict(X_test)
    accuracy = metrics.accuracy_score(y_test, predictions)
    warning_msg = None
    if accuracy < 0.9:
        warning_msg = f"Accuracy {accuracy} is below 0.9"
        warnings.warn(warning_msg, UserWarning)
    return accuracy, warning_msg
