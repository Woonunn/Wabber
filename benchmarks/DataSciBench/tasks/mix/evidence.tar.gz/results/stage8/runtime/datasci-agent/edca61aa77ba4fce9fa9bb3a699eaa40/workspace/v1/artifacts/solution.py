import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

def task_func(arr: np.ndarray) -> (plt.Axes, np.ndarray):
    row_sums = np.sum(arr, axis=1)
    mean = np.mean(row_sums)
    std = np.std(row_sums)
    if std == 0:
        normalized_data = np.zeros_like(row_sums, dtype=float)
    else:
        normalized_data = (row_sums - mean) / std

    fig, ax = plt.subplots()
    ax.hist(normalized_data, bins=30, density=True, alpha=0.6, color='green')

    x = np.linspace(norm.ppf(0.005), norm.ppf(0.995), 100)
    ax.plot(x, norm.pdf(x), 'r-', lw=2)

    ax.set_title("Histogram of Normalized Data with Standard Normal PDF")

    return ax, normalized_data
