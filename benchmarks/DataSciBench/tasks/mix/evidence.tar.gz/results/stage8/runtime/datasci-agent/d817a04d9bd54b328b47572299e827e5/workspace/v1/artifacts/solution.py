import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.datasets import load_iris

def task_func():
    plt.rcParams['font.family'] = 'Arial'
    iris = load_iris()
    df = pd.DataFrame(iris.data, columns=iris.feature_names)
    df['species'] = [iris.target_names[t] for t in iris.target]
    axis_labels = list(iris.feature_names)
    g = sns.pairplot(df, hue='species')
    g.fig.suptitle('Iris Dataset Pair Plot')
    for ax in g.axes.flatten():
        if ax is not None:
            ax.set_xlabel(ax.get_xlabel())
            ax.set_ylabel(ax.get_ylabel())
    return g.fig, axis_labels
