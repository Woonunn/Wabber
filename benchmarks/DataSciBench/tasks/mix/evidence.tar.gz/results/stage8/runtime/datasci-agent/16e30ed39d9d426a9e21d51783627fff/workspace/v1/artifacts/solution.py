import re
import numpy as np
from collections import Counter
from Levenshtein import ratio

# Constants
ALPHANUMERIC = re.compile('[\W_]+')

def task_func(text1, text2):
    def clean(text):
        return ALPHANUMERIC.sub(' ', text).lower()

    c1 = clean(text1)
    c2 = clean(text2)

    tokens1 = c1.split()
    tokens2 = c2.split()

    counter1 = Counter(tokens1)
    counter2 = Counter(tokens2)

    vocab = set(counter1) | set(counter2)

    vec1 = np.array([counter1.get(w, 0) for w in vocab], dtype=float)
    vec2 = np.array([counter2.get(w, 0) for w in vocab], dtype=float)

    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)

    if norm1 == 0 or norm2 == 0:
        cosine_similarity = 0.0
    else:
        cosine_similarity = float(np.dot(vec1, vec2) / (norm1 * norm2))

    levenshtein_ratio = float(ratio(c1, c2))

    return (cosine_similarity, levenshtein_ratio)
