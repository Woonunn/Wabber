import re
import matplotlib.pyplot as plt
import numpy as np

def task_func(text, rwidth=0.8):
    words = re.findall(r"[A-Za-z']+", text)
    word_lengths = [len(w) for w in words]
    fig, ax = plt.subplots()
    if word_lengths:
        bins = np.arange(min(word_lengths), max(word_lengths) + 2) - 0.5
        ax.hist(word_lengths, bins=bins, rwidth=rwidth)
    else:
        ax.hist(word_lengths, rwidth=rwidth)
    return ax, word_lengths
