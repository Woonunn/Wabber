from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import pandas as pd

def task_func(df):
    df_filled = df.copy()
    for col in df_filled.columns:
        if pd.api.types.is_numeric_dtype(df_filled[col]):
            df_filled[col] = df_filled[col].fillna(df_filled[col].mean())
    scaler = MinMaxScaler()
    norm_array = scaler.fit_transform(df_filled)
    norm_df = pd.DataFrame(norm_array, columns=df_filled.columns, index=df_filled.index)
    fig, ax = plt.subplots()
    norm_df.boxplot(ax=ax)
    return norm_df, ax
