import pandas as pd
import numpy as np

def task_func(test_scores, student):
    df = pd.DataFrame(test_scores)
    if student not in df['Student'].values:
        raise ValueError('student is not present in the test_scores dataframe.')
    student_scores = df[df['Student'] == student]['Score']
    avg_std = np.array([student_scores.mean(), student_scores.std(ddof=1)])
    return avg_std, df
