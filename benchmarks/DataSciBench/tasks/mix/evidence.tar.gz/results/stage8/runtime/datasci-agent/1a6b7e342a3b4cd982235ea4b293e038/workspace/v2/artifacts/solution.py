import pandas as pd
import matplotlib.pyplot as plt


def task_func(df: pd.DataFrame):
    if df is None or df.empty:
        raise ValueError("DataFrame is empty or contains non-numeric data.")
    if not all(pd.api.types.is_numeric_dtype(df[col]) for col in df.columns):
        raise ValueError("DataFrame is empty or contains non-numeric data.")

    cumulative_sums = df.cumsum()

    fig, ax = plt.subplots()
    cumulative_sums.plot(kind='bar', ax=ax)
    ax.set_title('Cumulative Sum per Column')
    ax.set_xlabel('Index')
    ax.set_ylabel('Cumulative Sum')
    ax.legend()

    return cumulative_sums, fig
