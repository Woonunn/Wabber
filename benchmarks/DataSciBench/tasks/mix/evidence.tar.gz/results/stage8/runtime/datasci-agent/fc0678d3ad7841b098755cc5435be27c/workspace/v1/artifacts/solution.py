from collections import Counter
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

def task_func(list_of_menuitems):
    flattened_items = []
    def flatten(lst):
        for item in lst:
            if isinstance(item, (list, tuple)):
                flatten(item)
            else:
                flattened_items.append(item)
    flatten(list_of_menuitems)
    if not flattened_items:
        return None, flattened_items
    counts = Counter(flattened_items)
    df = pd.DataFrame(list(counts.items()), columns=['item', 'count'])
    df = df.sort_values('count', ascending=False)
    fig, ax = plt.subplots()
    sns.barplot(data=df, x='item', y='count', ax=ax)
    return ax, flattened_items
