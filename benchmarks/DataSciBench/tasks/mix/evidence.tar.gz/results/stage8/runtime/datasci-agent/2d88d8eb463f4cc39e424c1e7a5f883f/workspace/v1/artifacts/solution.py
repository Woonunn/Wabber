import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler

def task_func(data: pd.DataFrame) -> (pd.DataFrame, plt.Axes):
    scaler = MinMaxScaler()
    normalized_array = scaler.fit_transform(data)
    normalized_data = pd.DataFrame(normalized_array, columns=data.columns, index=data.index)
    fig, ax = plt.subplots()
    sns.heatmap(normalized_data, cmap="YlGnBu", ax=ax, cbar_kws={"label": "Normalized Value"})
    return normalized_data, ax
