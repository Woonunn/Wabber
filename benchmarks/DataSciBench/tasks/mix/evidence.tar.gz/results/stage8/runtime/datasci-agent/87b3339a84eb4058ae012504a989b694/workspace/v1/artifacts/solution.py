import collections
import seaborn as sns
import matplotlib.pyplot as plt

def task_func(dictionary, new_key, new_value):
    dictionary[new_key] = new_value
    keys = list(dictionary.keys())
    values = list(dictionary.values())
    fig, ax = plt.subplots()
    sns.barplot(x=keys, y=values, ax=ax)
    return dictionary, ax
