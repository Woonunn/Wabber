import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def task_func(list_of_pairs):
    df = pd.DataFrame(list_of_pairs, columns=['Category', 'Value'])
    fig, ax = plt.subplots()
    sns.barplot(data=df, x='Category', y='Value', ax=ax)
    ax.set_title('Category vs Value')
    return df, ax
