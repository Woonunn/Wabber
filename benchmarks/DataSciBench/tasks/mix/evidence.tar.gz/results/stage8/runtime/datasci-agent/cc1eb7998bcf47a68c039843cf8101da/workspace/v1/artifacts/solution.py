import pandas as pd
from collections import Counter

def task_func(data):
    required_keys = ['Name', 'Age', 'Score']
    if not all(key in data for key in required_keys):
        raise ValueError("The dictionary does not have the required keys.")

    df = pd.DataFrame(data)
    sorted_df = df.sort_values(by=['Name', 'Age'], ascending=True).reset_index(drop=True)

    avg_scores = df.groupby('Name')['Score'].mean()

    if df.empty or df['Age'].dropna().empty:
        common_age = None
    else:
        age_counts = Counter(df['Age'].dropna())
        common_age = age_counts.most_common(1)[0][0]

    return sorted_df, avg_scores, common_age
