import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler

def task_func(df):
    if not isinstance(df, pd.DataFrame) or df.empty:
        raise ValueError("Input must be a non-empty pandas DataFrame")
    normalized_df = df.copy()
    last_col = normalized_df.columns[-1]
    scaler = MinMaxScaler()
    normalized_df[[last_col]] = scaler.fit_transform(normalized_df[[last_col]])
    fig, ax = plt.subplots()
    ax.plot(normalized_df.index, normalized_df[last_col])
    ax.set_title(f'Normalized Data of {last_col}')
    ax.set_xlabel('Index')
    ax.set_ylabel('Normalized Value')
    return normalized_df, ax
