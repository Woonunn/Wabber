import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def task_func(df):
    if df is None or df.empty:
        raise ValueError("The dataframe is empty.")
    if 'date' not in df.columns:
        raise ValueError("Required column 'date' is missing.")
    if not pd.api.types.is_datetime64_any_dtype(df['date']):
        raise ValueError("'date' column is not in datetime format.")

    df = df.copy()
    df['date'] = df['date'].apply(lambda x: x.toordinal())

    numeric_df = df.select_dtypes(include='number')

    corr_matrix = numeric_df.corr()

    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', ax=ax)
    ax.set_title('Correlation Matrix')

    pair_plot = sns.pairplot(numeric_df)

    return fig, pair_plot
