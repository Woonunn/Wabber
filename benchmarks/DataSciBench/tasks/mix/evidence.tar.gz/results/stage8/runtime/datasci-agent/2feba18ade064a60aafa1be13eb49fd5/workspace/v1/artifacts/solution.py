import pandas as pd
from sklearn.linear_model import LinearRegression

def task_func(df, target):
    X = df.drop(columns=[target])
    y = df[target]
    model = LinearRegression()
    model.fit(X, y)
    score = model.score(X, y)
    return score, model
