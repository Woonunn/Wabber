import pandas as pd
import matplotlib.pyplot as plt

def task_func(df, dct, columns=None, plot_histograms=False):
    if not isinstance(df, pd.DataFrame):
        raise ValueError("Input df must be a pandas DataFrame")

    replaced_df = df.replace(dct)

    hist_fig = None
    if plot_histograms:
        if columns is None:
            columns = list(replaced_df.columns)
        else:
            columns = [c for c in columns if c in replaced_df.columns]
        n = len(columns)
        if n > 0:
            hist_fig, axes = plt.subplots(n, 1, figsize=(6, 3 * n), squeeze=False)
            for ax, col in zip(axes.flatten(), columns):
                data = replaced_df[col].dropna()
                try:
                    ax.hist(data)
                except Exception:
                    pass
                ax.set_title(str(col))
            hist_fig.tight_layout()
        else:
            hist_fig = plt.figure()

    return replaced_df, hist_fig
