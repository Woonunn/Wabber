import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

PLOT_TITLE = 'Square root plot'
X_LABEL = 'x'
Y_LABEL = 'sqrt(x)'
TIME_FORMAT = '%Y-%m-%d %H:%M:%S'

def task_func(result):
    values = [d['from_user'] for d in result if isinstance(d, dict) and 'from_user' in d]
    sqrt_values = np.round(np.sqrt(np.array(values, dtype=float)), 2)
    fig, ax = plt.subplots()
    ax.plot(sqrt_values)
    ax.set_title(PLOT_TITLE)
    ax.set_xlabel(X_LABEL)
    ax.set_ylabel(Y_LABEL)
    ax.annotate(datetime.now().strftime(TIME_FORMAT), xy=(0.5, 0.95), xycoords='axes fraction', ha='center')
    return sqrt_values, ax
