import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

def task_func(data_matrix, n_components=2):
    pca = PCA(n_components=n_components)
    transformed = pca.fit_transform(data_matrix)
    columns = [f'Component {i+1}' for i in range(n_components)]
    pca_df = pd.DataFrame(transformed, columns=columns)
    pca_df['Mean'] = pca_df[columns].mean(axis=1)
    cum_var = pca.explained_variance_ratio_.cumsum()
    fig, ax = plt.subplots()
    ax.plot(range(1, n_components + 1), cum_var, marker='o')
    ax.set_xlabel('Number of Components')
    ax.set_ylabel('Cumulative Explained Variance')
    return pca_df, ax
