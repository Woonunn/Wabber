import pandas as pd
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

def task_func(df):
    if not isinstance(df, pd.DataFrame) or df.empty:
        raise ValueError("Input must be a non-empty pandas DataFrame")
    pca = PCA(n_components=2)
    components = pca.fit_transform(df)
    pca_df = pd.DataFrame(
        data=components,
        columns=['Principal Component 1', 'Principal Component 2']
    )
    fig, ax = plt.subplots()
    ax.scatter(
        pca_df['Principal Component 1'],
        pca_df['Principal Component 2']
    )
    ax.set_title('2 Component PCA')
    ax.set_xlabel('Principal Component 1')
    ax.set_ylabel('Principal Component 2')
    return pca_df, ax
