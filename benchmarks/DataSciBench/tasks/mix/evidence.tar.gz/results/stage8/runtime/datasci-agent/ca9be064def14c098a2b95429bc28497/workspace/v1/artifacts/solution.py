import collections
import itertools
import matplotlib.pyplot as plt

# Constants
ITEMS = ['apple', 'banana']

def task_func(a, b, items=ITEMS):
    combined = list(a) + list(b)
    counter = collections.Counter(combined)
    freq_dict = {item: counter.get(item, 0) for item in items}
    fig, ax = plt.subplots()
    ax.bar(list(freq_dict.keys()), list(freq_dict.values()))
    ax.set_xlabel('Items')
    ax.set_ylabel('Frequency')
    ax.set_title('Frequency of Predefined Items')
    return ax, freq_dict
