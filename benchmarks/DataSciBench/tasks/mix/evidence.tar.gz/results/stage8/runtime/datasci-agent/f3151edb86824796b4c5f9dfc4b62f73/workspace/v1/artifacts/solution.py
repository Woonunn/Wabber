import collections
import matplotlib.pyplot as plt

def task_func(data):
    total_sales = collections.defaultdict(int)
    for entry in data:
        for fruit, qty in entry.items():
            if qty < 0:
                raise ValueError("Sales quantity must not be negative")
            total_sales[fruit] += qty
    total_sales = dict(total_sales)
    if not total_sales:
        return total_sales, None
    colors_pool = ['red', 'yellow', 'green', 'blue', 'purple']
    fruits = list(total_sales.keys())
    values = [total_sales[f] for f in fruits]
    colors = [colors_pool[i % len(colors_pool)] for i in range(len(fruits))]
    fig, ax = plt.subplots()
    bars = ax.bar(fruits, values, color=colors)
    return total_sales, bars
