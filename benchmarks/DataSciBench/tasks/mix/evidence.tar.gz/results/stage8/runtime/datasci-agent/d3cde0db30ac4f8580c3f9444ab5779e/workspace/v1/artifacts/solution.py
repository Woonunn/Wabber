import pandas as pd
import statsmodels.api as sm

def task_func(df: pd.DataFrame, height: int, weight: int, columns: list) -> tuple:
    if df is None or df.empty:
        return None, False
    try:
        subset = df[(df[columns[1]] > height) & (df[columns[2]] < weight)]
    except KeyError:
        return None, False
    if subset.empty:
        return None, False
    y = subset[columns[0]]
    X = subset[columns[1:]]
    X = sm.add_constant(X)
    try:
        model = sm.OLS(y, X).fit()
    except Exception:
        return None, False
    return model, True
