import re
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

def task_func(df):
    if 'Title' not in df.columns or 'Content' not in df.columns:
        fig, ax = plt.subplots()
        ax.set_ylabel('TF-IDF Score')
        return ax, True

    mask = df['Title'].astype(str).str.contains(r'\b(how|what)\b', case=False, regex=True)
    filtered = df[mask]

    if filtered.empty:
        fig, ax = plt.subplots()
        ax.set_ylabel('TF-IDF Score')
        return ax, True

    contents = filtered['Content'].astype(str).tolist()

    try:
        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform(contents)
    except ValueError:
        fig, ax = plt.subplots()
        ax.set_ylabel('TF-IDF Score')
        return ax, True

    feature_names = vectorizer.get_feature_names_out()
    scores = np.asarray(tfidf_matrix.mean(axis=0)).ravel()

    fig, ax = plt.subplots()
    ax.bar(range(len(feature_names)), scores)
    ax.set_ylabel('TF-IDF Score')
    ax.set_xticks(range(len(feature_names)))
    ax.set_xticklabels(feature_names, rotation=90)

    return ax, False
