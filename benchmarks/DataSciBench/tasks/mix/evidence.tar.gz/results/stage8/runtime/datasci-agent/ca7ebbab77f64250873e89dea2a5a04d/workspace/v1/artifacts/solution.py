import re
import matplotlib.pyplot as plt
from nltk.probability import FreqDist

def task_func(example_str, top_n=30):
    # Remove text enclosed in square brackets
    cleaned = re.sub(r'\[[^\]]*\]', ' ', example_str)
    # Extract words
    words = re.findall(r'\b\w+\b', cleaned)
    freq_dist = FreqDist(words)
    common_words = dict(freq_dist.most_common(top_n))
    fig, ax = plt.subplots()
    items = freq_dist.most_common()
    if items:
        labels = [w for w, _ in items]
        counts = [c for _, c in items]
        ax.bar(range(len(labels)), counts)
        ax.set_xticks(range(len(labels)))
        ax.set_xticklabels(labels, rotation=90)
    ax.set_xlabel('Words')
    ax.set_ylabel('Frequency')
    ax.set_title('Word Frequency Distribution')
    return ax, common_words
