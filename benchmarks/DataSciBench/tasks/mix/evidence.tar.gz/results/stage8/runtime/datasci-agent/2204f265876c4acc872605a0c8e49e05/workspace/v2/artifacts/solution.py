from datetime import datetime
import pandas as pd
import pytz
import matplotlib.pyplot as plt

DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
TIMEZONES = [
    "America/New_York",
    "Europe/London",
    "Asia/Shanghai",
    "Asia/Tokyo",
    "Australia/Sydney",
]

def task_func(timestamp):
    utc_dt = datetime.fromtimestamp(timestamp, tz=pytz.utc)
    datetimes = []
    for tz_name in TIMEZONES:
        tz = pytz.timezone(tz_name)
        local_dt = utc_dt.astimezone(tz)
        datetimes.append(local_dt.replace(tzinfo=None))
    df = pd.DataFrame({
        "Timezone": TIMEZONES,
        "Datetime": pd.to_datetime(datetimes),
    })
    fig, ax = plt.subplots()
    ax.bar(df["Timezone"], df["Datetime"])
    ax.set_xlabel("Timezone")
    ax.set_ylabel("Datetime")
    ax.set_title("Datetime = f(Timezone)")
    return df, ax
