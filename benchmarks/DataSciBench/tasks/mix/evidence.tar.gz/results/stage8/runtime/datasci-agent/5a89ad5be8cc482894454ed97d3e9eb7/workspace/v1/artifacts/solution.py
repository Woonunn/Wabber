import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def task_func(data, column="c"):
    df = pd.DataFrame(data)
    if column in df.columns:
        df = df.drop(columns=[column])
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.shape[1] > 0 and numeric_df.shape[0] > 0:
        ax = numeric_df.plot()
    else:
        ax = None
    return df, ax
