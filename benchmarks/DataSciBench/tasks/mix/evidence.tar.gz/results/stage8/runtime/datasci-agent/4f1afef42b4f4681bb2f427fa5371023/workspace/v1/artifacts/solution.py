import numpy as np
import matplotlib.pyplot as plt

def task_func(arr):
    arr = np.asarray(arr)
    unique, counts = np.unique(arr, return_counts=True)
    uniform_distribution = bool(np.all(counts == counts[0]))
    bins = np.arange(len(unique) + 1) - 0.5
    fig, ax = plt.subplots()
    ax.hist(arr, bins=bins)
    return uniform_distribution, ax
