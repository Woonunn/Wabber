import time
import numpy as np

def task_func(samples=10, delay=0.1):
    delay_times = []
    for _ in range(samples):
        start = time.time()
        time.sleep(delay)
        end = time.time()
        delay_times.append(end - start)
    delay_times = np.array(delay_times)
    mean = float(np.mean(delay_times))
    stddev = float(np.std(delay_times))
    return mean, stddev
