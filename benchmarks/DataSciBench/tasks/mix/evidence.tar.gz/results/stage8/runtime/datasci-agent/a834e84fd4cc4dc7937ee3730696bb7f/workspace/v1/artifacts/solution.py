import numpy as np
from itertools import chain

def task_func(L):
    flat = list(chain.from_iterable(L))
    mean = float(np.mean(flat))
    variance = float(np.var(flat))
    mean_var = {'mean': mean, 'variance': variance}
    return mean_var, mean, variance
