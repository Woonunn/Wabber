from matplotlib import pyplot as plt
from sklearn.decomposition import PCA
import numpy as np

def task_func(arr):
    row_sums = np.sum(arr, axis=1).reshape(-1, 1)
    pca = PCA(n_components=1)
    pca.fit(row_sums)
    explained_variance = float(pca.explained_variance_ratio_[0])
    fig, ax = plt.subplots()
    ax.bar(['PC1'], [explained_variance])
    ax.set_title("Explained Variance Ratio of Principal Components")
    ax.set_ylabel('Explained Variance Ratio')
    return ax, explained_variance
