import numpy as np
from scipy import stats

def task_func(df):
    p_values = {}
    test_results = {}
    for col in df.columns:
        data = df[col].dropna()
        stat, p = stats.shapiro(data)
        p_values[col] = p
        test_results[col] = bool(p > 0.05)
    return p_values, test_results
