import seaborn as sns
import numpy as np
import pandas as pd

def task_func(df):
    if df is None or df.empty:
        raise ValueError("The DataFrame is empty.")
    if not all(np.issubdtype(dtype, np.number) for dtype in df.dtypes):
        raise TypeError("The DataFrame contains non-numeric data types.")
    covariance_df = df.cov()
    pair_plot = sns.pairplot(df)
    return covariance_df, pair_plot
