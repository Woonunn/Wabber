import pandas as pd
import seaborn as sns
import numpy as np
import ast
import matplotlib.pyplot as plt

def task_func(csv_file):
    df = pd.read_csv(csv_file)
    df['list'] = df['list'].apply(ast.literal_eval)
    df['sum'] = df['list'].apply(np.sum)
    df['mean'] = df['list'].apply(np.mean)
    df['std'] = df['list'].apply(np.std)
    fig, ax = plt.subplots()
    sns.histplot(df['mean'], ax=ax)
    return df, ax
