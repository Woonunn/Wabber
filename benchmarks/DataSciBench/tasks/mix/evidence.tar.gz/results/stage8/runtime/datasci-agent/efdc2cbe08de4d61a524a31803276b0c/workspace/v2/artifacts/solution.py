import string
import matplotlib.pyplot as plt

def task_func(s):
    if not isinstance(s, str):
        raise TypeError("Input must be a string")
    letter_freq = {ch: 0 for ch in string.ascii_lowercase}
    for ch in s.lower():
        if ch in letter_freq:
            letter_freq[ch] += 1
    letters = list(string.ascii_lowercase)
    freqs = [letter_freq[ch] for ch in letters]
    fig, ax = plt.subplots()
    ax.bar(letters, freqs)
    ax.set_title('Letter Frequencies')
    ax.set_xlabel('Letters')
    ax.set_ylabel('Frequency')
    return letter_freq, ax
