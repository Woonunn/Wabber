import pandas as pd
import seaborn as sns
from scipy.stats import zscore
import matplotlib.pyplot as plt

def task_func(data_matrix):
    z = zscore(data_matrix, axis=1)
    n = z.shape[1]
    cols = ['Feature ' + str(i) for i in range(1, n + 1)]
    z_scores_df = pd.DataFrame(z, columns=cols)
    z_scores_df['Mean'] = z_scores_df.mean(axis=1)
    corr = z_scores_df.corr()
    fig, ax = plt.subplots()
    sns.heatmap(corr, ax=ax)
    return z_scores_df, ax
