import numpy as np
from collections import Counter

def task_func(list_of_tuples):
    sum_numeric = 0
    categories = []
    for value, category in list_of_tuples:
        sum_numeric += value
        categories.append(category)
    category_counts = dict(Counter(categories))
    return (sum_numeric, category_counts)
