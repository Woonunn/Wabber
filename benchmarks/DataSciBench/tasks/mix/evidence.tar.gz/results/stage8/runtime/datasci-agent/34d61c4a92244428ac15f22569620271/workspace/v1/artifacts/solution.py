import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm
from itertools import chain

def task_func(L):
    flattened_list = list(chain.from_iterable(L))
    data = np.array(flattened_list, dtype=float)
    mu, std = norm.fit(data)
    fig, ax = plt.subplots()
    ax.hist(data, bins='auto', density=True, alpha=0.6, color='g')
    xmin, xmax = ax.get_xlim()
    x = np.linspace(xmin, xmax, 100)
    p = norm.pdf(x, mu, std)
    ax.plot(x, p, 'k', linewidth=2)
    return ax, flattened_list
