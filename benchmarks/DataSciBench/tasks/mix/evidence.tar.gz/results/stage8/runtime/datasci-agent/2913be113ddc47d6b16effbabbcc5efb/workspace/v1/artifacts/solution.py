import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt

def task_func(data_dict, data_keys):
    keys = [k for k in data_keys if k in data_dict]
    if not keys:
        raise ValueError("No keys in data_keys found in data_dict")
    df = pd.DataFrame({k: data_dict[k] for k in keys})
    scaler = MinMaxScaler()
    normalized = scaler.fit_transform(df)
    normalized_df = pd.DataFrame(normalized, columns=keys)
    fig, ax = plt.subplots()
    normalized_df.plot(ax=ax)
    return normalized_df, ax
