import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import numpy as np

def task_func(s1, s2, n_clusters=3):
    if not isinstance(s1, pd.Series) or not isinstance(s2, pd.Series):
        raise ValueError("s1 and s2 must be pandas Series")
    if len(s1) != len(s2):
        raise ValueError("s1 and s2 must have the same length")
    data = np.column_stack((s1.values, s2.values))
    kmeans = KMeans(n_clusters=n_clusters)
    cluster_labels = kmeans.fit_predict(data)
    fig, ax = plt.subplots()
    scatter = ax.scatter(data[:, 0], data[:, 1], c=cluster_labels, cmap='viridis')
    ax.set_title("K-Means Clustering")
    legend_elements = scatter.legend_elements()[0]
    ax.legend(legend_elements, [f"Cluster {i}" for i in range(n_clusters)])
    return cluster_labels, ax
