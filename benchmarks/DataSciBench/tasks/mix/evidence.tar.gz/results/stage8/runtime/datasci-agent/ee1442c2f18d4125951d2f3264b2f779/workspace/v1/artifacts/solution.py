import numpy as np
import matplotlib.pyplot as plt

COLORS = ['r', 'g', 'b']

def task_func(df, group_col, value_col):
    if not np.issubdtype(df[value_col].dtype, np.number):
        raise TypeError("'Value' has non-numeric values")

    groups = df[group_col].unique()
    means = []
    stds = []
    for g in groups:
        vals = df[df[group_col] == g][value_col]
        means.append(vals.mean())
        stds.append(vals.std())

    colors = [COLORS[i % len(COLORS)] for i in range(len(groups))]

    fig, ax = plt.subplots()
    ax.bar(range(len(groups)), means, yerr=stds, color=colors, capsize=5)
    ax.set_xticks(range(len(groups)))
    ax.set_xticklabels([str(g) for g in groups])

    title = f"Bar chart of {value_col} by {group_col}"
    ax.set_title(title)
    ax.set_xlabel(group_col)
    ax.set_ylabel(value_col)

    return ax, title
