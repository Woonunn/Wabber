import pandas as pd
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

FEATURE_NAMES = ["Feature 1", "Feature 2", "Feature 3", "Feature 4", "Feature 5"]

def task_func(data_matrix):
    scaler = StandardScaler()
    std_array = scaler.fit_transform(data_matrix)
    std_data = pd.DataFrame(std_array, columns=FEATURE_NAMES)
    std_data['Mean'] = std_data.mean(axis=1)
    fig, hist_ax = plt.subplots()
    hist_ax.hist(std_data['Mean'])
    hist_ax.set_title('Distribution of Means')
    return std_data, hist_ax
