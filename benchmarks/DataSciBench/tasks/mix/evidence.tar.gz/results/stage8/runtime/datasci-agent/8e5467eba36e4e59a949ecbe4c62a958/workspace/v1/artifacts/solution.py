import pandas as pd
from statsmodels.tsa.stattools import adfuller

def task_func(df: pd.DataFrame, column_a: str, column_b: str, column_c: str) -> bool:
    filtered = df[(df[column_b] > 50) & (df[column_c] == 900)]
    series = filtered[column_a]
    if series.empty or series.nunique() <= 1:
        return (True, 1.0)
    result = adfuller(series)
    p_value = result[1]
    is_stationary = p_value < 0.05
    return (is_stationary, p_value)
