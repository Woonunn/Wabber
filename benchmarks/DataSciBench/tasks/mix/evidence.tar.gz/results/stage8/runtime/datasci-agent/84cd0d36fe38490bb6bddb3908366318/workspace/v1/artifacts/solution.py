import numpy as np
from operator import itemgetter
import matplotlib.pyplot as plt

def task_func(data):
    points = list(data)
    max_y_point = max(points, key=itemgetter(1))
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    fig, ax = plt.subplots()
    ax.scatter(xs, ys)
    ax.scatter([max_y_point[0]], [max_y_point[1]], color='red')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_title('Points with Max Y Point Highlighted')
    return ax, max_y_point
