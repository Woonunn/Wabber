import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def task_func(df):
    df = df.copy()
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        df[col] = df[col].fillna(df[col].mean())
    stats_df = df[numeric_cols].describe()
    stats_df = stats_df.loc[['count', 'mean', 'std', 'min', '25%', '50%', '75%', 'max']]
    dist_plots = []
    for col in numeric_cols:
        fig, ax = plt.subplots()
        sns.histplot(df[col], bins=10, ax=ax)
        dist_plots.append(ax)
    return stats_df, dist_plots
