import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats

def task_func(df: pd.DataFrame, column_name: str) -> (str, plt.Axes):
    fig, ax = plt.subplots()
    if df is None or df.empty or column_name not in df.columns or df[column_name].dropna().empty:
        ax.set_title(f"Distribution of values in {column_name} (No Data)")
        return "The DataFrame is empty or the specified column has no data.", ax

    data = df[column_name].dropna()
    counts = data.value_counts()
    n_unique = len(counts)

    if n_unique <= 1:
        uniform = True
    else:
        observed = counts.values.astype(float)
        expected = np.full(n_unique, observed.sum() / n_unique)
        chi2, p = stats.chisquare(observed, expected)
        # Stricter threshold to reliably detect non-uniformity
        uniform = p > 0.05 and (np.max(np.abs(observed - expected)) / expected.mean() < 0.1)

    message = "The distribution of values is uniform." if uniform else "The distribution of values is not uniform."

    ax.hist(data, bins=n_unique, edgecolor='black', alpha=0.7)
    ax.set_xlabel("Values")
    ax.set_ylabel("Frequency")
    ax.set_title(f"Distribution of values in {column_name}")
    return message, ax
