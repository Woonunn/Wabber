import numpy as np
from collections import Counter
from scipy.stats import norm
import matplotlib.pyplot as plt
import pandas as pd

def task_func(df, bins=4):
    if not isinstance(df, pd.DataFrame):
        raise TypeError("df must be a pandas DataFrame")
    if 'value' not in df.columns:
        raise TypeError("DataFrame must contain a 'value' column")
    values = df['value']
    if not np.issubdtype(values.dtype, np.number):
        raise TypeError("'value' column must be numeric")
    counts = Counter(values)
    duplicates_count = Counter({k: v for k, v in counts.items() if v > 1})
    fig, ax = plt.subplots()
    data = values.dropna().to_numpy()
    ax.hist(data, bins=bins, density=True, color='green', alpha=0.6)
    if data.size > 1 and np.std(data) > 0:
        mu, std = norm.fit(data)
        x = np.linspace(data.min(), data.max(), 100)
        ax.plot(x, norm.pdf(x, mu, std), 'k-', linewidth=2)
    ax.set_title("Distribution")
    ax.set_xlabel("Value")
    ax.set_ylabel("Frequency")
    return duplicates_count, ax
