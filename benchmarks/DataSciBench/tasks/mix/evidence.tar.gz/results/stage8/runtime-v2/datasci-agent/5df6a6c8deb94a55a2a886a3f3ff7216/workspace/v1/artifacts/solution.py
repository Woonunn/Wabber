import ast
import pandas as pd
import seaborn as sns

def task_func(csv_file):
    df = pd.read_csv(csv_file)
    if 'dict_column' in df.columns:
        df['dict_column'] = df['dict_column'].apply(
            lambda x: ast.literal_eval(x) if isinstance(x, str) else x
        )
    ax = sns.pairplot(df)
    return df, ax
