import pandas as pd
import os
import numpy as np
import ast
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def task_func(directory):
    csv_files = [f for f in os.listdir(directory) if f.endswith('.csv')]
    if not csv_files:
        return pd.DataFrame(columns=['email', 'list', 'sum', 'mean', 'median']), None
    longest = max(csv_files, key=len)
    path = os.path.join(directory, longest)
    df = pd.read_csv(path)
    def parse_list(x):
        if isinstance(x, str):
            return ast.literal_eval(x)
        return x
    lists = df['list'].apply(parse_list)
    df['sum'] = lists.apply(lambda l: np.sum(l))
    df['mean'] = lists.apply(lambda l: np.mean(l))
    df['median'] = lists.apply(lambda l: np.median(l))
    fig, ax = plt.subplots()
    ax.hist(df['median'])
    return df, ax
