import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def task_func(csv_file_path: str, title: str):
    df = pd.read_csv(csv_file_path)
    corr = df.corr().round(2)
    fig, ax = plt.subplots()
    sns.heatmap(corr, annot=True, ax=ax)
    ax.set_title(title)
    return corr, ax
